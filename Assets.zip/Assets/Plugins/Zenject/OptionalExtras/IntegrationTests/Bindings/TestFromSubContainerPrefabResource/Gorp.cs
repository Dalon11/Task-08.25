namespace Zenject.Tests.Bindings.FromSubContainerPrefabResource
{
    public class Gorp
    {
    }
}

