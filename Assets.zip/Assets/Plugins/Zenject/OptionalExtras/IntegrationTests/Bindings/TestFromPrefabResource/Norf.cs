using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefabResource
{
    public interface INorf
    {
    }

    public class Norf : MonoBehaviour, INorf
    {
    }
}
